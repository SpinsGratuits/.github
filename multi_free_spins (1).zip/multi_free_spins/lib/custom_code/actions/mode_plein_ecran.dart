// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/ff_builtin_enums.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart' hide RepeatMode;
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:flutter/services.dart';

Future modePleinEcran() async {
  // Masque la barre de navigation du bas et la barre d'état du haut
  // Les barres réapparaissent temporairement si l'utilisateur glisse son doigt depuis le bord.
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
}

// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the `</>` button on the right!
